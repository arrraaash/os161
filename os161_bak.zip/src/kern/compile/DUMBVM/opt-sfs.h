/* Automatically generated; do not edit */
#ifndef _OPT_SFS_H_
#define _OPT_SFS_H_
#define OPT_SFS 1
#endif /* _OPT_SFS_H_ */
